import { WhatsappIcon } from "./Icons";
import { WHATSAPP_NUMBER } from "../data/products";

export default function Footer() {
  return (
    <footer className="relative mt-12 border-t border-white/10">
      {/* CTA Banner */}
      <div className="max-w-7xl mx-auto px-5 sm:px-8 -mt-20">
        <div className="relative overflow-hidden rounded-[32px] border border-white/10 bg-gradient-to-br from-[#4f8ef7]/20 via-[#a78bfa]/15 to-[#07070d] backdrop-blur p-10 sm:p-14 text-center">
          <div className="absolute -top-20 -right-20 w-80 h-80 rounded-full bg-[#a78bfa]/30 blur-3xl" />
          <div className="absolute -bottom-32 -left-20 w-80 h-80 rounded-full bg-[#4f8ef7]/30 blur-3xl" />
          <div className="relative">
            <h2 className="font-display text-3xl sm:text-5xl font-extrabold leading-tight">
              Prêt à passer à <span className="text-gradient">la vitesse supérieure</span> ?
            </h2>
            <p className="text-gray-300 mt-4 max-w-xl mx-auto">
              Discutez avec un conseiller sur WhatsApp pour un devis personnalisé en quelques minutes.
            </p>
            <a
              href={`https://wa.me/${WHATSAPP_NUMBER}`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 mt-7 px-7 py-3.5 rounded-full bg-gradient-to-r from-emerald-500 to-green-500 text-white font-bold hover:shadow-xl hover:shadow-emerald-500/30 hover:-translate-y-0.5 transition"
            >
              <WhatsappIcon size={18} />
              Démarrer la conversation
            </a>
          </div>
        </div>
      </div>

      {/* Footer content */}
      <div className="max-w-7xl mx-auto px-5 sm:px-8 pt-20 pb-10">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10">
          <div>
            <div className="flex items-center gap-2">
              <span className="grid place-items-center w-9 h-9 rounded-xl bg-gradient-to-br from-[#4f8ef7] to-[#a78bfa]">
                <span className="text-white font-black">T</span>
              </span>
              <span className="font-display text-xl font-extrabold">
                Tech<span className="text-gradient">Zone</span>
              </span>
            </div>
            <p className="text-sm text-gray-400 mt-4 leading-relaxed">
              Votre boutique premium pour iPhone, MacBook et HP. 100% authentique, livraison rapide.
            </p>
          </div>

          <div>
            <h4 className="font-display font-bold mb-4">Catalogue</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="#iphones" className="hover:text-white transition">iPhone 17 Series</a></li>
              <li><a href="#macbooks" className="hover:text-white transition">MacBook M5</a></li>
              <li><a href="#hp" className="hover:text-white transition">HP Gaming & Pro</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display font-bold mb-4">Aide</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="#faq" className="hover:text-white transition">FAQ</a></li>
              <li><a href="#features" className="hover:text-white transition">Garanties</a></li>
              <li><a href={`https://wa.me/${WHATSAPP_NUMBER}`} className="hover:text-white transition">Support WhatsApp</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display font-bold mb-4">Contact</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li>📍 Kinshasa, RDC</li>
              <li>📞 +243 982 686 451</li>
              <li>✉️ hello@techzone.cd</li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-gray-500">
          <div>© 2026 TechZone — Tous droits réservés.</div>
          <div className="flex gap-5">
            <a href="#" className="hover:text-white transition">Mentions légales</a>
            <a href="#" className="hover:text-white transition">Confidentialité</a>
            <a href="#" className="hover:text-white transition">CGV</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

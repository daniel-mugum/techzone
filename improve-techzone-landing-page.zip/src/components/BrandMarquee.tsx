const brands = ["Apple", "HP", "iPhone 17", "MacBook M5", "OMEN", "EliteBook", "M5 Max", "RTX 4070", "Authentique", "Express 24h"];

export default function BrandMarquee() {
  const items = [...brands, ...brands];
  return (
    <div className="relative py-6 border-y border-white/10 bg-white/[0.02] overflow-hidden">
      <div className="absolute left-0 top-0 bottom-0 w-24 bg-gradient-to-r from-[#07070d] to-transparent z-10" />
      <div className="absolute right-0 top-0 bottom-0 w-24 bg-gradient-to-l from-[#07070d] to-transparent z-10" />
      <div className="flex animate-marquee whitespace-nowrap">
        {items.map((b, i) => (
          <div key={i} className="flex items-center gap-12 px-6">
            <span className="font-display text-xl sm:text-2xl font-bold text-gray-500 hover:text-white transition">
              {b}
            </span>
            <span className="text-[#a78bfa]/40">✦</span>
          </div>
        ))}
      </div>
    </div>
  );
}

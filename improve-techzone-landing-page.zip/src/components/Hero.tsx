import { ArrowRight, SparkleIcon, WhatsappIcon, StarIcon } from "./Icons";
import { WHATSAPP_NUMBER } from "../data/products";

export default function Hero() {
  return (
    <section id="top" className="relative min-h-[100svh] flex items-center pt-20 pb-24 overflow-hidden">
      {/* Background layers */}
      <div className="absolute inset-0 -z-10 bg-grid opacity-50" />
      <div className="absolute -z-10 top-1/4 -left-32 w-[500px] h-[500px] rounded-full bg-[#4f8ef7] opacity-20 blur-[120px] animate-blob" />
      <div className="absolute -z-10 bottom-0 right-0 w-[600px] h-[600px] rounded-full bg-[#a78bfa] opacity-20 blur-[140px] animate-blob" style={{ animationDelay: "4s" }} />
      <div className="absolute -z-10 top-0 right-1/3 w-[400px] h-[400px] rounded-full bg-fuchsia-500 opacity-10 blur-[120px] animate-blob" style={{ animationDelay: "8s" }} />
      <div className="absolute -z-10 inset-0 bg-gradient-to-b from-transparent via-transparent to-[#07070d]" />

      <div className="max-w-7xl mx-auto px-5 sm:px-8 w-full grid lg:grid-cols-[1.1fr_1fr] gap-12 items-center">
        {/* Left content */}
        <div className="text-center lg:text-left animate-fade-up">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 backdrop-blur text-xs font-semibold tracking-wider">
            <SparkleIcon size={14} className="text-[#a78bfa]" />
            <span className="text-gray-300">COLLECTION PREMIUM 2026</span>
            <span className="w-1 h-1 rounded-full bg-emerald-400 animate-pulse" />
          </div>

          <h1 className="font-display mt-6 text-5xl sm:text-6xl lg:text-7xl font-extrabold leading-[0.95]">
            La tech <br className="hidden sm:block" />
            <span className="text-gradient">haut de gamme</span>
            <br /> commence ici.
          </h1>

          <p className="mt-6 text-gray-400 text-base sm:text-lg leading-relaxed max-w-xl mx-auto lg:mx-0">
            iPhone 17, MacBook M5, HP OMEN, EliteBook et plus encore. Produits 100% authentiques,
            livraison express à Kinshasa et paiement à la réception.
          </p>

          <div className="mt-9 flex flex-wrap items-center gap-3 justify-center lg:justify-start">
            <a
              href="#iphones"
              className="group inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-gradient-to-r from-[#4f8ef7] to-[#a78bfa] text-white font-semibold shadow-[0_15px_40px_-10px_rgba(79,142,247,0.6)] hover:shadow-[0_20px_50px_-10px_rgba(167,139,250,0.7)] hover:-translate-y-0.5 transition-all"
            >
              Voir les produits
              <ArrowRight size={16} className="group-hover:translate-x-1 transition" />
            </a>
            <a
              href={`https://wa.me/${WHATSAPP_NUMBER}`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full border border-white/15 bg-white/5 backdrop-blur text-white font-semibold hover:bg-white/10 hover:border-white/30 transition"
            >
              <WhatsappIcon size={18} className="text-emerald-400" />
              Commander sur WhatsApp
            </a>
          </div>

          {/* Stats row */}
          <div className="mt-10 grid grid-cols-3 gap-4 max-w-lg mx-auto lg:mx-0">
            {[
              { v: "12K+", l: "Clients satisfaits" },
              { v: "4.9★", l: "Note moyenne" },
              { v: "24h", l: "Livraison Kin" },
            ].map((s) => (
              <div key={s.l} className="p-4 rounded-2xl border border-white/10 bg-white/[0.03] backdrop-blur">
                <div className="font-display text-2xl font-extrabold text-gradient">{s.v}</div>
                <div className="text-xs text-gray-400 mt-1">{s.l}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Right showcase */}
        <div className="relative animate-fade-up" style={{ animationDelay: "0.2s" }}>
          <div className="relative aspect-[4/5] max-w-md mx-auto">
            {/* Glow ring */}
            <div className="absolute inset-0 rounded-[40px] bg-gradient-to-br from-[#4f8ef7]/40 via-[#a78bfa]/30 to-fuchsia-500/30 blur-2xl" />

            {/* Main card */}
            <div className="relative h-full rounded-[40px] border border-white/10 bg-gradient-to-br from-white/10 to-white/[0.02] backdrop-blur-xl overflow-hidden p-6 flex flex-col">
              <div className="flex justify-between items-start">
                <div>
                  <div className="text-[10px] tracking-[3px] font-bold text-[#a78bfa] uppercase">Édition spéciale</div>
                  <div className="font-display text-2xl font-extrabold mt-1">iPhone 17 Pro Max</div>
                </div>
                <div className="px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  EN STOCK
                </div>
              </div>

              <div className="flex-1 grid place-items-center my-4">
                <img
                  src="https://images.pexels.com/photos/14979024/pexels-photo-14979024.jpeg?auto=compress&cs=tinysrgb&w=800"
                  alt="iPhone 17 Pro Max"
                  className="w-full h-full object-cover rounded-2xl animate-float shadow-2xl"
                />
              </div>

              <div className="flex items-end justify-between">
                <div>
                  <div className="flex items-center gap-1 text-amber-400 mb-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <StarIcon key={i} size={12} />
                    ))}
                    <span className="text-gray-400 text-xs ml-1">4.9 · 248 avis</span>
                  </div>
                  <div className="flex items-baseline gap-2">
                    <div className="font-display text-3xl font-extrabold text-white">$1199</div>
                    <div className="text-sm text-gray-500 line-through">$1299</div>
                  </div>
                </div>
                <a
                  href="#iphones"
                  className="grid place-items-center w-12 h-12 rounded-full bg-gradient-to-br from-[#4f8ef7] to-[#a78bfa] text-white hover:scale-110 transition shadow-lg shadow-[#4f8ef7]/40"
                >
                  <ArrowRight size={18} />
                </a>
              </div>
            </div>

            {/* Floating mini cards */}
            <div className="hidden sm:flex absolute -left-6 top-12 px-3 py-2 rounded-2xl bg-white/10 backdrop-blur-xl border border-white/15 shadow-2xl animate-float gap-2 items-center" style={{ animationDelay: "1s" }}>
              <div className="grid place-items-center w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400">✓</div>
              <div>
                <div className="text-[10px] text-gray-400">Authentique</div>
                <div className="text-xs font-bold">Garanti 1 an</div>
              </div>
            </div>
            <div className="hidden sm:flex absolute -right-4 bottom-20 px-3 py-2 rounded-2xl bg-white/10 backdrop-blur-xl border border-white/15 shadow-2xl animate-float gap-2 items-center" style={{ animationDelay: "2s" }}>
              <div className="grid place-items-center w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400">🚀</div>
              <div>
                <div className="text-[10px] text-gray-400">Livré en</div>
                <div className="text-xs font-bold">24 heures</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

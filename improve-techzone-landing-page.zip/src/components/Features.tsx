import { ShieldIcon, TruckIcon, SparkleIcon, HeadsetIcon } from "./Icons";

const features = [
  {
    icon: ShieldIcon,
    title: "100% Authentique",
    desc: "Tous nos produits sont scellés d'origine avec garantie internationale.",
    color: "from-emerald-500/20 to-teal-500/20",
    iconColor: "text-emerald-400",
  },
  {
    icon: TruckIcon,
    title: "Livraison Express",
    desc: "Livré en 24h à Kinshasa, 48-72h dans toutes les provinces de la RDC.",
    color: "from-blue-500/20 to-cyan-500/20",
    iconColor: "text-blue-400",
  },
  {
    icon: SparkleIcon,
    title: "Modèles 2026",
    desc: "Les dernières nouveautés Apple et HP disponibles dès la sortie mondiale.",
    color: "from-fuchsia-500/20 to-purple-500/20",
    iconColor: "text-fuchsia-400",
  },
  {
    icon: HeadsetIcon,
    title: "Support 7j/7",
    desc: "Notre équipe est joignable sur WhatsApp tous les jours pour vous accompagner.",
    color: "from-amber-500/20 to-orange-500/20",
    iconColor: "text-amber-400",
  },
];

export default function Features() {
  return (
    <section id="features" className="relative py-24 px-5 sm:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="text-xs font-bold tracking-[3px] text-[#a78bfa] uppercase">
            Pourquoi TechZone
          </div>
          <h2 className="font-display text-4xl sm:text-5xl font-extrabold mt-3">
            Une expérience d'achat <span className="text-gradient">premium</span>.
          </h2>
          <p className="text-gray-400 mt-4">
            Bien plus qu'une boutique : un service haut de gamme, du choix jusqu'à la livraison.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {features.map((f) => (
            <div
              key={f.title}
              className="group relative p-6 rounded-3xl border border-white/10 bg-gradient-to-b from-white/[0.04] to-transparent hover:border-white/20 transition overflow-hidden"
            >
              <div className={`absolute -top-10 -right-10 w-40 h-40 rounded-full bg-gradient-to-br ${f.color} blur-3xl opacity-0 group-hover:opacity-100 transition-opacity`} />
              <div className={`relative grid place-items-center w-12 h-12 rounded-2xl bg-white/5 border border-white/10 ${f.iconColor}`}>
                <f.icon size={22} />
              </div>
              <h3 className="font-display font-bold text-lg mt-5">{f.title}</h3>
              <p className="text-sm text-gray-400 mt-2 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

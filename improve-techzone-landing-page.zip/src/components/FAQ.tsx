import { useState } from "react";
import { PlusIcon, MinusIcon } from "./Icons";

const faqs = [
  {
    q: "Vos produits sont-ils 100% authentiques ?",
    a: "Oui, tous nos appareils sont neufs, scellés d'origine et accompagnés d'une facture ainsi que d'une garantie internationale.",
  },
  {
    q: "Quels sont les délais et zones de livraison ?",
    a: "Livraison en 24h à Kinshasa, 48 à 72h dans les autres provinces de la RDC. Suivi en temps réel via WhatsApp.",
  },
  {
    q: "Quels modes de paiement acceptez-vous ?",
    a: "Paiement à la réception (cash), Mobile Money (Airtel, Orange, M-Pesa) ou virement bancaire avant livraison.",
  },
  {
    q: "Puis-je échanger un produit après réception ?",
    a: "Oui, vous disposez de 7 jours pour signaler un défaut ou demander un échange si l'article est encore scellé.",
  },
  {
    q: "Proposez-vous une garantie locale ?",
    a: "Tous nos produits bénéficient d'une garantie atelier de 12 mois en plus de la garantie constructeur internationale.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="py-24 px-5 sm:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <div className="text-xs font-bold tracking-[3px] text-[#a78bfa] uppercase">FAQ</div>
          <h2 className="font-display text-4xl sm:text-5xl font-extrabold mt-3">
            Vos <span className="text-gradient">questions</span>, nos réponses.
          </h2>
        </div>

        <div className="space-y-3">
          {faqs.map((f, i) => {
            const isOpen = open === i;
            return (
              <div
                key={f.q}
                className={`rounded-2xl border transition-all ${
                  isOpen
                    ? "border-[#a78bfa]/40 bg-gradient-to-b from-white/[0.06] to-transparent"
                    : "border-white/10 bg-white/[0.02] hover:border-white/20"
                }`}
              >
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="w-full flex items-center justify-between gap-4 p-5 text-left"
                >
                  <span className="font-display font-bold text-base sm:text-lg">{f.q}</span>
                  <span
                    className={`shrink-0 grid place-items-center w-8 h-8 rounded-full border transition ${
                      isOpen
                        ? "bg-gradient-to-br from-[#4f8ef7] to-[#a78bfa] text-white border-transparent"
                        : "border-white/15 text-gray-300"
                    }`}
                  >
                    {isOpen ? <MinusIcon size={14} /> : <PlusIcon size={14} />}
                  </span>
                </button>
                <div
                  className={`grid transition-all duration-300 ${
                    isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                  }`}
                >
                  <div className="overflow-hidden">
                    <p className="px-5 pb-5 text-gray-400 leading-relaxed">{f.a}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

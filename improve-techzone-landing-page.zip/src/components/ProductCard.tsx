import type { Product } from "../data/products";
import { CartIcon, StarIcon, CheckIcon, PlusIcon } from "./Icons";

type Props = {
  product: Product;
  onAdd: (p: Product) => void;
  added?: boolean;
};

export default function ProductCard({ product, onAdd, added }: Props) {
  const discount = product.oldPrice
    ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100)
    : 0;

  return (
    <article className="group relative rounded-3xl border border-white/10 bg-gradient-to-b from-white/[0.04] to-white/[0.01] overflow-hidden hover:border-white/20 hover:-translate-y-1 transition-all duration-300 hover:shadow-[0_30px_60px_-20px_rgba(79,142,247,0.3)]">
      {/* Image */}
      <div className={`relative h-64 overflow-hidden bg-gradient-to-br ${product.accent}`}>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/30" />
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="absolute inset-0 w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
        />

        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5">
          {product.badge && (
            <span className="px-2.5 py-1 rounded-full bg-black/60 backdrop-blur text-white text-[10px] font-bold border border-white/20">
              {product.badge}
            </span>
          )}
          {discount > 0 && (
            <span className="px-2.5 py-1 rounded-full bg-gradient-to-r from-rose-500 to-pink-500 text-white text-[10px] font-bold">
              −{discount}%
            </span>
          )}
        </div>

        {/* Stock */}
        <div className="absolute top-3 right-3">
          {product.inStock ? (
            <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/20 backdrop-blur border border-emerald-400/30 text-emerald-300 text-[10px] font-bold">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Stock
            </span>
          ) : (
            <span className="px-2.5 py-1 rounded-full bg-rose-500/20 backdrop-blur border border-rose-400/30 text-rose-300 text-[10px] font-bold">
              Rupture
            </span>
          )}
        </div>
      </div>

      {/* Info */}
      <div className="p-5">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[10px] font-bold tracking-[2px] text-gray-500 uppercase">
            {product.brand}
          </span>
          <div className="flex items-center gap-1 text-amber-400">
            <StarIcon size={12} />
            <span className="text-xs text-gray-300 font-semibold">{product.rating}</span>
            <span className="text-xs text-gray-500">({product.reviews})</span>
          </div>
        </div>

        <h3 className="font-display font-bold text-lg leading-tight">{product.name}</h3>
        <p className="text-xs text-gray-500 mt-0.5">{product.tagline}</p>

        <ul className="mt-3 space-y-1">
          {product.specs.slice(0, 3).map((s) => (
            <li key={s} className="flex items-center gap-2 text-xs text-gray-400">
              <CheckIcon size={12} className="text-[#a78bfa] shrink-0" />
              <span className="truncate">{s}</span>
            </li>
          ))}
        </ul>

        <div className="mt-4 flex items-end justify-between">
          <div>
            {product.oldPrice && (
              <div className="text-xs text-gray-500 line-through">${product.oldPrice}</div>
            )}
            <div className="font-display text-2xl font-extrabold text-gradient">
              ${product.price}
            </div>
          </div>
          <button
            disabled={!product.inStock}
            onClick={() => onAdd(product)}
            className={`relative overflow-hidden grid place-items-center px-4 h-11 rounded-xl font-semibold text-sm transition-all ${
              product.inStock
                ? added
                  ? "bg-emerald-500 text-white"
                  : "bg-gradient-to-r from-[#4f8ef7] to-[#a78bfa] text-white hover:shadow-lg hover:shadow-[#4f8ef7]/40 hover:scale-105"
                : "bg-white/5 text-gray-500 cursor-not-allowed"
            }`}
          >
            {added ? (
              <span className="flex items-center gap-1.5">
                <CheckIcon size={14} /> Ajouté
              </span>
            ) : (
              <span className="flex items-center gap-1.5">
                {product.inStock ? <PlusIcon size={14} /> : <CartIcon size={14} />}
                {product.inStock ? "Ajouter" : "Indisponible"}
              </span>
            )}
          </button>
        </div>
      </div>
    </article>
  );
}

import { StarIcon } from "./Icons";

const testimonials = [
  {
    name: "Jean-Marc K.",
    role: "Photographe · Kinshasa",
    text: "Mon iPhone 17 Pro Max livré en moins de 24h, scellé et avec facture. Service au top !",
    initials: "JK",
    color: "from-blue-500 to-cyan-500",
  },
  {
    name: "Sandra M.",
    role: "Étudiante · Lubumbashi",
    text: "J'ai eu mon MacBook Air M4 à un prix imbattable. L'équipe a été à l'écoute du début à la fin.",
    initials: "SM",
    color: "from-fuchsia-500 to-pink-500",
  },
  {
    name: "Patrick L.",
    role: "Gamer · Goma",
    text: "Le HP OMEN dépasse mes attentes. Performances de fou, et livraison rapide jusqu'à Goma 🔥",
    initials: "PL",
    color: "from-amber-500 to-orange-500",
  },
];

export default function Testimonials() {
  return (
    <section className="relative py-24 px-5 sm:px-8 overflow-hidden">
      <div className="absolute -z-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] rounded-full bg-[#4f8ef7]/10 blur-[120px]" />

      <div className="max-w-7xl mx-auto">
        <div className="flex flex-wrap items-end justify-between gap-6 mb-12">
          <div>
            <div className="text-xs font-bold tracking-[3px] text-[#a78bfa] uppercase">Témoignages</div>
            <h2 className="font-display text-4xl sm:text-5xl font-extrabold mt-3 max-w-xl">
              Ils nous font <span className="text-gradient">confiance</span>.
            </h2>
          </div>
          <div className="flex items-center gap-3 px-5 py-3 rounded-2xl bg-white/5 border border-white/10">
            <div className="flex text-amber-400">
              {Array.from({ length: 5 }).map((_, i) => (
                <StarIcon key={i} size={16} />
              ))}
            </div>
            <div>
              <div className="font-display font-extrabold text-xl">4.9/5</div>
              <div className="text-xs text-gray-400">+12 000 commandes</div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-5">
          {testimonials.map((t) => (
            <div
              key={t.name}
              className="p-6 rounded-3xl border border-white/10 bg-gradient-to-b from-white/[0.04] to-transparent backdrop-blur hover:border-white/20 transition"
            >
              <div className="flex text-amber-400 mb-4">
                {Array.from({ length: 5 }).map((_, i) => (
                  <StarIcon key={i} size={14} />
                ))}
              </div>
              <p className="text-gray-300 leading-relaxed">"{t.text}"</p>
              <div className="flex items-center gap-3 mt-6 pt-5 border-t border-white/10">
                <div className={`grid place-items-center w-11 h-11 rounded-full bg-gradient-to-br ${t.color} font-bold text-white`}>
                  {t.initials}
                </div>
                <div>
                  <div className="font-semibold">{t.name}</div>
                  <div className="text-xs text-gray-500">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

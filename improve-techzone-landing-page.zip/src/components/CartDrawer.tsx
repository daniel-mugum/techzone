import { useEffect } from "react";
import type { Product } from "../data/products";
import { WHATSAPP_NUMBER } from "../data/products";
import { CloseIcon, MinusIcon, PlusIcon, TrashIcon, WhatsappIcon, CartIcon } from "./Icons";

export type CartItem = { product: Product; qty: number };

type Props = {
  open: boolean;
  items: CartItem[];
  onClose: () => void;
  onInc: (id: string) => void;
  onDec: (id: string) => void;
  onRemove: (id: string) => void;
};

export default function CartDrawer({ open, items, onClose, onInc, onDec, onRemove }: Props) {
  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const subtotal = items.reduce((s, i) => s + i.product.price * i.qty, 0);
  const shipping = subtotal > 0 ? (subtotal > 1500 ? 0 : 15) : 0;
  const total = subtotal + shipping;

  const orderMessage = encodeURIComponent(
    `Bonjour TechZone 👋\n\nJe souhaite commander :\n\n${items
      .map((i) => `• ${i.product.name} × ${i.qty} — $${i.product.price * i.qty}`)
      .join("\n")}\n\nSous-total : $${subtotal}\nLivraison : ${
      shipping === 0 ? "Offerte" : `$${shipping}`
    }\nTOTAL : $${total}\n\nMerci !`
  );
  const waLink = `https://wa.me/${WHATSAPP_NUMBER}?text=${orderMessage}`;

  return (
    <>
      {/* Overlay */}
      <div
        onClick={onClose}
        className={`fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm transition-opacity ${
          open ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
      />
      {/* Drawer */}
      <aside
        className={`fixed top-0 right-0 z-[70] h-full w-full sm:w-[440px] bg-[#0a0a14] border-l border-white/10 shadow-2xl flex flex-col transition-transform duration-300 ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <header className="flex items-center justify-between p-5 border-b border-white/10">
          <div>
            <h2 className="font-display text-xl font-extrabold">Votre panier</h2>
            <p className="text-xs text-gray-500 mt-0.5">
              {items.length === 0 ? "Vide pour le moment" : `${items.length} article${items.length > 1 ? "s" : ""}`}
            </p>
          </div>
          <button
            onClick={onClose}
            className="grid place-items-center w-10 h-10 rounded-full border border-white/10 hover:bg-white/5 transition"
          >
            <CloseIcon size={18} />
          </button>
        </header>

        <div className="flex-1 overflow-y-auto p-5">
          {items.length === 0 ? (
            <div className="h-full grid place-items-center text-center px-6">
              <div>
                <div className="mx-auto w-20 h-20 grid place-items-center rounded-2xl bg-white/5 border border-white/10 mb-4">
                  <CartIcon size={28} className="text-gray-500" />
                </div>
                <h3 className="font-display font-bold text-lg">Votre panier est vide</h3>
                <p className="text-sm text-gray-500 mt-2">
                  Parcourez notre catalogue d'iPhone, MacBook et HP.
                </p>
                <button
                  onClick={onClose}
                  className="mt-5 px-5 py-2.5 rounded-full bg-gradient-to-r from-[#4f8ef7] to-[#a78bfa] font-semibold text-sm"
                >
                  Continuer mes achats
                </button>
              </div>
            </div>
          ) : (
            <ul className="space-y-3">
              {items.map(({ product, qty }) => (
                <li
                  key={product.id}
                  className="flex gap-3 p-3 rounded-2xl border border-white/10 bg-white/[0.03]"
                >
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-20 h-20 object-cover rounded-xl shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="text-[10px] font-bold tracking-wider text-gray-500 uppercase">
                          {product.brand}
                        </div>
                        <h4 className="font-semibold text-sm truncate">{product.name}</h4>
                      </div>
                      <button
                        onClick={() => onRemove(product.id)}
                        className="text-gray-500 hover:text-rose-400 transition shrink-0"
                        aria-label="Retirer"
                      >
                        <TrashIcon size={14} />
                      </button>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center gap-1 border border-white/10 rounded-full p-0.5">
                        <button
                          onClick={() => onDec(product.id)}
                          className="w-7 h-7 grid place-items-center rounded-full hover:bg-white/5"
                        >
                          <MinusIcon size={12} />
                        </button>
                        <span className="w-6 text-center text-sm font-semibold">{qty}</span>
                        <button
                          onClick={() => onInc(product.id)}
                          className="w-7 h-7 grid place-items-center rounded-full hover:bg-white/5"
                        >
                          <PlusIcon size={12} />
                        </button>
                      </div>
                      <div className="font-display font-extrabold text-[#a78bfa]">
                        ${product.price * qty}
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {items.length > 0 && (
          <footer className="border-t border-white/10 p-5 space-y-3 bg-[#0a0a14]">
            <div className="space-y-2 text-sm">
              <div className="flex justify-between text-gray-400">
                <span>Sous-total</span>
                <span className="text-white font-semibold">${subtotal}</span>
              </div>
              <div className="flex justify-between text-gray-400">
                <span>Livraison</span>
                <span className={`font-semibold ${shipping === 0 ? "text-emerald-400" : "text-white"}`}>
                  {shipping === 0 ? "Offerte 🎉" : `$${shipping}`}
                </span>
              </div>
              <div className="h-px bg-white/10" />
              <div className="flex justify-between items-baseline">
                <span className="font-semibold">Total</span>
                <span className="font-display text-2xl font-extrabold text-gradient">${total}</span>
              </div>
            </div>
            <a
              href={waLink}
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-center gap-2 w-full py-3.5 rounded-full bg-gradient-to-r from-emerald-500 to-green-500 text-white font-bold hover:shadow-lg hover:shadow-emerald-500/30 transition"
            >
              <WhatsappIcon size={18} />
              Commander sur WhatsApp
            </a>
            <p className="text-[11px] text-center text-gray-500">
              Paiement à la réception · Livraison 24h à Kinshasa
            </p>
          </footer>
        )}
      </aside>
    </>
  );
}

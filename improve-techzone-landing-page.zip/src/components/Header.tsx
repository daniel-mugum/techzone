import { useEffect, useState } from "react";
import { CartIcon, MenuIcon, CloseIcon } from "./Icons";

type Props = {
  cartCount: number;
  onCartClick: () => void;
};

const links = [
  { href: "#iphones", label: "iPhones" },
  { href: "#macbooks", label: "MacBooks" },
  { href: "#hp", label: "HP" },
  { href: "#features", label: "Garanties" },
  { href: "#faq", label: "FAQ" },
];

export default function Header({ cartCount, onCartClick }: Props) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[#07070d]/85 backdrop-blur-xl border-b border-white/10"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-5 sm:px-8 h-[72px] flex items-center justify-between">
        <a href="#top" className="flex items-center gap-2 group">
          <span className="relative grid place-items-center w-9 h-9 rounded-xl bg-gradient-to-br from-[#4f8ef7] to-[#a78bfa] shadow-lg shadow-[#4f8ef7]/30">
            <span className="text-white font-black text-lg">T</span>
            <span className="absolute inset-0 rounded-xl ring-1 ring-white/30 group-hover:ring-white/60 transition" />
          </span>
          <span className="font-display text-xl font-extrabold tracking-tight">
            Tech<span className="text-gradient">Zone</span>
          </span>
        </a>

        <nav className="hidden lg:flex items-center gap-1 p-1 rounded-full border border-white/10 bg-white/5 backdrop-blur">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="px-4 py-2 text-sm text-gray-300 hover:text-white rounded-full hover:bg-white/10 transition"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <button
            onClick={onCartClick}
            className="relative grid place-items-center w-11 h-11 rounded-full border border-white/10 bg-white/5 hover:bg-white/10 hover:border-white/20 transition"
            aria-label="Panier"
          >
            <CartIcon size={18} />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[20px] h-5 px-1 grid place-items-center rounded-full bg-gradient-to-br from-[#4f8ef7] to-[#a78bfa] text-[10px] font-bold text-white ring-2 ring-[#07070d]">
                {cartCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setMobileOpen((v) => !v)}
            className="lg:hidden grid place-items-center w-11 h-11 rounded-full border border-white/10 bg-white/5"
            aria-label="Menu"
          >
            {mobileOpen ? <CloseIcon size={20} /> : <MenuIcon size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="lg:hidden border-t border-white/10 bg-[#07070d]/95 backdrop-blur-xl">
          <div className="px-5 py-4 flex flex-col gap-1">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setMobileOpen(false)}
                className="px-4 py-3 rounded-xl text-gray-200 hover:bg-white/5 transition"
              >
                {l.label}
              </a>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}

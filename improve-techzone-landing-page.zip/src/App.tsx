import { useMemo, useState } from "react";
import { products, type Product } from "./data/products";
import Header from "./components/Header";
import Hero from "./components/Hero";
import ProductCard from "./components/ProductCard";
import CartDrawer, { type CartItem } from "./components/CartDrawer";
import Features from "./components/Features";
import Testimonials from "./components/Testimonials";
import FAQ from "./components/FAQ";
import Footer from "./components/Footer";
import BrandMarquee from "./components/BrandMarquee";
import { CheckIcon } from "./components/Icons";

type SectionConfig = {
  id: string;
  label: string;
  emoji: string;
  title: string;
  highlight: string;
  description: string;
  category: Product["category"];
  filters?: { key: string; label: string }[];
};

const sections: SectionConfig[] = [
  {
    id: "iphones",
    label: "Apple · 2026",
    emoji: "📱",
    title: "iPhone",
    highlight: "17 Series",
    description: "Du Pro Max au modèle Air, découvrez la gamme la plus avancée jamais conçue.",
    category: "iphone",
    filters: [
      { key: "all", label: "Tous" },
      { key: "pro", label: "Pro" },
      { key: "air", label: "Air" },
      { key: "standard", label: "Standard" },
    ],
  },
  {
    id: "macbooks",
    label: "Apple Silicon",
    emoji: "💻",
    title: "MacBook",
    highlight: "M5 Series",
    description: "Puissance, autonomie et silence avec les nouvelles puces Apple M5.",
    category: "macbook",
  },
  {
    id: "hp",
    label: "HP · 2026",
    emoji: "🎮",
    title: "HP",
    highlight: "Gaming & Pro",
    description: "Du gaming RTX au pro EliteBook, des machines pensées pour performer.",
    category: "hp",
  },
];

function matchesFilter(p: Product, filter: string) {
  if (filter === "all") return true;
  const n = p.name.toLowerCase();
  if (filter === "pro") return n.includes("pro");
  if (filter === "air") return n.includes("air");
  if (filter === "standard") return !n.includes("pro") && !n.includes("air");
  return true;
}

export default function App() {
  const [cart, setCart] = useState<Record<string, number>>({});
  const [cartOpen, setCartOpen] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [addedFlash, setAddedFlash] = useState<string | null>(null);
  const [filters, setFilters] = useState<Record<string, string>>({ iphones: "all" });

  const cartItems: CartItem[] = useMemo(
    () =>
      Object.entries(cart)
        .map(([id, qty]) => {
          const product = products.find((p) => p.id === id);
          return product ? { product, qty } : null;
        })
        .filter((x): x is CartItem => !!x),
    [cart]
  );
  const cartCount = cartItems.reduce((s, i) => s + i.qty, 0);

  const addToCart = (p: Product) => {
    setCart((c) => ({ ...c, [p.id]: (c[p.id] ?? 0) + 1 }));
    setAddedFlash(p.id);
    setToast(`${p.name} ajouté au panier`);
    setTimeout(() => setAddedFlash(null), 1500);
    setTimeout(() => setToast(null), 2500);
  };

  const inc = (id: string) => setCart((c) => ({ ...c, [id]: (c[id] ?? 0) + 1 }));
  const dec = (id: string) =>
    setCart((c) => {
      const next = { ...c };
      if ((next[id] ?? 0) <= 1) delete next[id];
      else next[id] = next[id] - 1;
      return next;
    });
  const remove = (id: string) =>
    setCart((c) => {
      const next = { ...c };
      delete next[id];
      return next;
    });

  return (
    <div className="min-h-screen relative">
      <Header cartCount={cartCount} onCartClick={() => setCartOpen(true)} />

      <main>
        <Hero />
        <BrandMarquee />

        {sections.map((s) => {
          const sectionProducts = products.filter((p) => p.category === s.category);
          const filter = filters[s.id] ?? "all";
          const visible = sectionProducts.filter((p) => matchesFilter(p, filter));

          return (
            <section key={s.id} id={s.id} className="py-20 px-5 sm:px-8 scroll-mt-20">
              <div className="max-w-7xl mx-auto">
                <div className="flex flex-wrap items-end justify-between gap-6 mb-10">
                  <div className="max-w-2xl">
                    <div className="text-xs font-bold tracking-[3px] text-[#a78bfa] uppercase">
                      {s.label}
                    </div>
                    <h2 className="font-display text-4xl sm:text-5xl font-extrabold mt-3 flex items-center gap-3 flex-wrap">
                      <span className="text-3xl sm:text-4xl">{s.emoji}</span>
                      {s.title} <span className="text-gradient">{s.highlight}</span>
                    </h2>
                    <p className="text-gray-400 mt-4">{s.description}</p>
                  </div>

                  {s.filters && (
                    <div className="flex flex-wrap gap-2 p-1 rounded-full border border-white/10 bg-white/[0.03]">
                      {s.filters.map((f) => (
                        <button
                          key={f.key}
                          onClick={() => setFilters((cur) => ({ ...cur, [s.id]: f.key }))}
                          className={`px-4 py-1.5 text-xs font-semibold rounded-full transition ${
                            filter === f.key
                              ? "bg-gradient-to-r from-[#4f8ef7] to-[#a78bfa] text-white shadow-md"
                              : "text-gray-400 hover:text-white"
                          }`}
                        >
                          {f.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                  {visible.map((p) => (
                    <ProductCard
                      key={p.id}
                      product={p}
                      onAdd={addToCart}
                      added={addedFlash === p.id}
                    />
                  ))}
                </div>

                {visible.length === 0 && (
                  <div className="text-center py-16 rounded-3xl border border-dashed border-white/10 text-gray-500">
                    Aucun produit dans cette catégorie pour le moment.
                  </div>
                )}
              </div>
            </section>
          );
        })}

        <Features />
        <Testimonials />
        <FAQ />
      </main>

      <Footer />

      <CartDrawer
        open={cartOpen}
        items={cartItems}
        onClose={() => setCartOpen(false)}
        onInc={inc}
        onDec={dec}
        onRemove={remove}
      />

      {/* Toast */}
      <div
        className={`fixed bottom-6 left-1/2 -translate-x-1/2 z-[80] transition-all duration-300 ${
          toast ? "opacity-100 translate-y-0" : "opacity-0 translate-y-3 pointer-events-none"
        }`}
      >
        <div className="flex items-center gap-3 px-5 py-3 rounded-full bg-[#0a0a14]/95 backdrop-blur border border-white/15 shadow-2xl">
          <span className="grid place-items-center w-7 h-7 rounded-full bg-emerald-500 text-white">
            <CheckIcon size={14} />
          </span>
          <span className="text-sm font-medium pr-2">{toast}</span>
          <button
            onClick={() => {
              setToast(null);
              setCartOpen(true);
            }}
            className="text-xs font-bold text-[#a78bfa] hover:text-white transition"
          >
            Voir le panier →
          </button>
        </div>
      </div>
    </div>
  );
}

export type Product = {
  id: string;
  brand: "Apple" | "HP";
  category: "iphone" | "macbook" | "hp";
  name: string;
  tagline: string;
  specs: string[];
  price: number;
  oldPrice?: number;
  badge?: string;
  rating: number;
  reviews: number;
  image: string;
  accent: string; // tailwind gradient classes
  inStock: boolean;
};

export const products: Product[] = [
  // iPhones
  {
    id: "iphone-17-pro-max",
    brand: "Apple",
    category: "iphone",
    name: "iPhone 17 Pro Max",
    tagline: "Le summum du Pro.",
    specs: ["Puce A19 Pro", "256 Go", "Titanium Natural", "ProMotion 120Hz", "Triple caméra 48MP"],
    price: 1199,
    oldPrice: 1299,
    badge: "Best-seller",
    rating: 4.9,
    reviews: 248,
    image: "https://images.pexels.com/photos/14979024/pexels-photo-14979024.jpeg?auto=compress&cs=tinysrgb&w=900",
    accent: "from-blue-500/30 to-purple-500/30",
    inStock: true,
  },
  {
    id: "iphone-17-air",
    brand: "Apple",
    category: "iphone",
    name: "iPhone 17 Air",
    tagline: "Ultra-fin. Ultra-puissant.",
    specs: ["Puce A19", "Châssis 5.5mm", "OLED Super Retina", "USB-C 10Gb/s", "Action Button"],
    price: 999,
    badge: "Nouveau",
    rating: 4.8,
    reviews: 132,
    image: "https://images.pexels.com/photos/37467615/pexels-photo-37467615.jpeg?auto=compress&cs=tinysrgb&w=900",
    accent: "from-sky-400/30 to-cyan-400/30",
    inStock: true,
  },
  {
    id: "iphone-17",
    brand: "Apple",
    category: "iphone",
    name: "iPhone 17",
    tagline: "L'essentiel, sublimé.",
    specs: ["Puce A19", "128 Go", "Dynamic Island", "Double caméra 48MP", "5 coloris"],
    price: 799,
    rating: 4.7,
    reviews: 86,
    image: "https://images.pexels.com/photos/9995703/pexels-photo-9995703.jpeg?auto=compress&cs=tinysrgb&w=900",
    accent: "from-pink-500/30 to-rose-500/30",
    inStock: true,
  },
  {
    id: "iphone-16-pro",
    brand: "Apple",
    category: "iphone",
    name: "iPhone 16 Pro",
    tagline: "Toujours au sommet.",
    specs: ["Puce A18 Pro", "256 Go", "Titanium", "ProMotion 120Hz"],
    price: 949,
    oldPrice: 1099,
    badge: "-14%",
    rating: 4.8,
    reviews: 412,
    image: "https://images.pexels.com/photos/31059294/pexels-photo-31059294.jpeg?auto=compress&cs=tinysrgb&w=900",
    accent: "from-amber-400/30 to-orange-500/30",
    inStock: true,
  },

  // MacBooks
  {
    id: "macbook-pro-m5-max",
    brand: "Apple",
    category: "macbook",
    name: "MacBook Pro M5 Max",
    tagline: "Conçu pour les pros.",
    specs: ["Puce M5 Max", "48 Go RAM", "1 To SSD", "Liquid Retina XDR 16″", "22h autonomie"],
    price: 3899,
    badge: "Édition Pro",
    rating: 5.0,
    reviews: 64,
    image: "https://images.pexels.com/photos/11621727/pexels-photo-11621727.jpeg?auto=compress&cs=tinysrgb&w=900",
    accent: "from-violet-500/30 to-fuchsia-500/30",
    inStock: true,
  },
  {
    id: "macbook-air-m4",
    brand: "Apple",
    category: "macbook",
    name: "MacBook Air M4",
    tagline: "Léger comme l'air.",
    specs: ["Puce M4", "16 Go RAM", "512 Go SSD", "Liquid Retina 13.6″", "24h autonomie"],
    price: 1299,
    oldPrice: 1499,
    badge: "Promo",
    rating: 4.9,
    reviews: 287,
    image: "https://images.pexels.com/photos/32966915/pexels-photo-32966915.jpeg?auto=compress&cs=tinysrgb&w=900",
    accent: "from-indigo-500/30 to-blue-500/30",
    inStock: true,
  },
  {
    id: "macbook-pro-m5",
    brand: "Apple",
    category: "macbook",
    name: "MacBook Pro M5 14″",
    tagline: "La puissance compacte.",
    specs: ["Puce M5", "24 Go RAM", "512 Go SSD", "Liquid Retina XDR 14″"],
    price: 2199,
    rating: 4.9,
    reviews: 118,
    image: "https://images.pexels.com/photos/249538/pexels-photo-249538.jpeg?auto=compress&cs=tinysrgb&w=900",
    accent: "from-emerald-500/30 to-teal-500/30",
    inStock: true,
  },

  // HP
  {
    id: "hp-omen-rtx4070",
    brand: "HP",
    category: "hp",
    name: "HP OMEN 16 RTX 4070",
    tagline: "La bête du gaming.",
    specs: ["Intel Core i9-14900HX", "RTX 4070 8 Go", "32 Go DDR5", "1 To SSD NVMe", "QHD 240Hz"],
    price: 1799,
    oldPrice: 1999,
    badge: "Gaming",
    rating: 4.8,
    reviews: 156,
    image: "https://images.pexels.com/photos/29878038/pexels-photo-29878038.jpeg?auto=compress&cs=tinysrgb&w=900",
    accent: "from-red-500/30 to-orange-500/30",
    inStock: true,
  },
  {
    id: "hp-elitebook-g11",
    brand: "HP",
    category: "hp",
    name: "HP EliteBook G11",
    tagline: "Pro. Élégant. Sécurisé.",
    specs: ["Intel Core Ultra 7", "16 Go RAM", "1 To SSD", "Écran OLED 14″", "Wi-Fi 7"],
    price: 1299,
    rating: 4.7,
    reviews: 92,
    image: "https://images.pexels.com/photos/8068269/pexels-photo-8068269.jpeg?auto=compress&cs=tinysrgb&w=900",
    accent: "from-cyan-500/30 to-blue-500/30",
    inStock: true,
  },
  {
    id: "hp-victus",
    brand: "HP",
    category: "hp",
    name: "HP Victus 15",
    tagline: "Gaming accessible.",
    specs: ["AMD Ryzen 7", "RTX 4060", "16 Go RAM", "512 Go SSD", "FHD 144Hz"],
    price: 1099,
    badge: "Top affaire",
    rating: 4.6,
    reviews: 203,
    image: "https://images.pexels.com/photos/7727496/pexels-photo-7727496.jpeg?auto=compress&cs=tinysrgb&w=900",
    accent: "from-fuchsia-500/30 to-pink-500/30",
    inStock: false,
  },
];

export const WHATSAPP_NUMBER = "243982686451";
